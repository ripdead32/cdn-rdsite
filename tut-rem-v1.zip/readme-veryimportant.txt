======================

               README

======================



This mod is intended for Psych Engine, any version is fine, just don't install the mod to the really old versions.



------------------------------------------------------------------------------------------------------------------------------------------------------------------

How to install the mod:

---------------------------------------------------------------------------------------------------------------------------------------------------------------------

after extracting TUT-REM-v1.zip you should see these 2 files/folders:



readme-veryimportant.txt

[ RIP_DEAD - TUTORIAL REMASTERED ]

readme-veryimportant.txt is the text file your reading right now, [ RIP_DEAD - TUTORIAL REMASTERED ] is the mod itself.



Go to your Psych Engine folder (as an example: C:\Users\Admin\Desktop\PsychEngine\Psych Engine)

head to the mods folder, if you didnt delete, you should see "readme.txt" inside the mods folder, if you want you can go ahead and read that but its just 1 line of text.

Drag (or copy) the [ RIP_DEAD - TUTORIAL REMASTERED ] folder onto Psych Engine's mods folder (as an example too.. C:\Users\Admin\Desktop\PsychEngine\Psych Engine\mods\[ RIP_DEAD - TUTORIAL REMASTERED]



then go ahead and launch PsychEngine.exe



-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Note That:

Do NOT install the mod onto Kade Engine, VSlice (Vanilla), Leather Engine, etc.. The mod does NOT work there.
If your not stupid then do NOT put readme-veryimportant.txt onto the mods folder
Do not put the contents of the [ RIP_DEAD - TUTORIAL REMASTERED ] folder to the mods folder, it will not work, put the entire folder to mods so that it looks like this (if your in a Windows 11 machine)



--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
[File Explorer Icon]  | mods | +                                                                                                                                                                                                                                                             -        []           X   
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      |                   
      |
      |
      |
      |                     [RIP_DEAD TUTORIAL REMASTERED]
      |                       readme.txt (if you have it)
      |
      |
      |
      |
      |
      |
      |
      |
      |
      |
      |
      |
      |
      |
      |
      |
      |
      |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                                                                                                                                                    [taskbar]
                                                                                                                                     
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

=====================================================================================
End of README, go and have fun (this probably took longer than what i was dealing with dialogues in story mod lmao) |
=====================================================================================